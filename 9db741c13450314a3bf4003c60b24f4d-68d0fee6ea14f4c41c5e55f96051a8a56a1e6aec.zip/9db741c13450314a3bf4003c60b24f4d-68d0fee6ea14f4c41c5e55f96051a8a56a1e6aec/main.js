const { app, BrowserWindow, globalShortcut } = require('electron');
const path = require('path');

let win;
let devToolsWindow; // Variable to hold the reference to the DevTools window

function createWindow() {
  // Path to the custom icon
  const iconPath = path.join('C:', 'Users', 'zohan', 'Downloads', 'BN', 'Electron-Devtools.ico');
  
  win = new BrowserWindow({
    width: 800,
    height: 600,
    icon: iconPath,  // Set the custom icon for the main window
    webPreferences: {
      nodeIntegration: true,
    },
  });

  // Remove the menu completely
  win.setMenu(null);

  // Load about:blank to avoid disconnect
  win.loadURL('about:blank');

  // Open DevTools in a separate window (undocked)
  win.webContents.openDevTools({ mode: 'undocked' });

  // Listen for the DevTools window to open and set the icon
  win.webContents.once('devtools-opened', () => {
    // Create a new BrowserWindow for the DevTools if it's not already created
    if (!devToolsWindow) {
      devToolsWindow = new BrowserWindow({
        parent: win,
        show: false, // Hide the DevTools window initially
        width: 800,
        height: 600,
        icon: iconPath, // Set the same custom icon for the DevTools window
        webPreferences: {
          nodeIntegration: true,
        },
      });

      // Show the DevTools window once it's ready
      devToolsWindow.once('ready-to-show', () => {
        devToolsWindow.show();
      });
    }
  });

  // Set up a global keyboard shortcut for opening DevTools in a new window
  globalShortcut.register('Alt+5', () => {
    if (!win.webContents.isDevToolsOpened()) {
      win.webContents.openDevTools({ mode: 'undocked' }); // Open in a new window
    }
  });
}

app.whenReady().then(() => {
  createWindow();

  // Quit application when all windows are closed
  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });
});

app.on('will-quit', () => {
  // Deregister the shortcut when the app quits
  globalShortcut.unregisterAll();
});
